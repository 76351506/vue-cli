export default {
  namespace: 'bbb',
  state: {
    name: 'bbb',
  },
  getters: {},
  mutations: {},
  actions: {},
}
